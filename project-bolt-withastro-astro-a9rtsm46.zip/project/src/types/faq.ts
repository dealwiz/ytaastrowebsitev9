export interface FAQSection {
  title: string;
  questions: {
    question: string;
    answer: string;
  }[];
}