export interface Database {
  public: {
    Tables: {
      success_stories: {
        Row: {
          id: string
          role: string
          company: string
          department: string
          industry: string
          candidate_name: string
          location: string
          image_url: string
          testimonial: string
          impact: string[]
          skills: string[]
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id: string
          role: string
          company: string
          department: string
          industry: string
          candidate_name: string
          location: string
          image_url: string
          testimonial: string
          impact?: string[] | null
          skills?: string[] | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          role?: string
          company?: string
          department?: string
          industry?: string
          candidate_name?: string
          location?: string
          image_url?: string
          testimonial?: string
          impact?: string[] | null
          skills?: string[] | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
      roles: {
        Row: {
          id: string
          title: string
          category: string
          category_description: string | null
          summary: string | null
          uk_salary_range: string | null
          lk_salary_range: string | null
          key_skills: string[] | null
          responsibilities: string[] | null
          created_at: string | null
          updated_at: string | null
        }
        Insert: {
          id: string
          title: string
          category: string
          category_description?: string | null
          summary?: string | null
          uk_salary_range?: string | null
          lk_salary_range?: string | null
          key_skills?: string[] | null
          responsibilities?: string[] | null
          created_at?: string | null
          updated_at?: string | null
        }
        Update: {
          id?: string
          title?: string
          category?: string
          category_description?: string | null
          summary?: string | null
          uk_salary_range?: string | null
          lk_salary_range?: string | null
          key_skills?: string[] | null
          responsibilities?: string[] | null
          created_at?: string | null
          updated_at?: string | null
        }
      }
    }
  }
}