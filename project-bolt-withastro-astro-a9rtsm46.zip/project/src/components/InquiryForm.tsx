import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import Airtable from 'airtable';

// Initialize Airtable
const base = new Airtable({ apiKey: 'patW2ORXa9Umyz1fi.c2b9362f52a1144f51f561712e93174016da82c042bdbf3024d7a7645cba738b' }).base('appmAkOtJVu8spJzy');

interface InquiryFormProps {
  roleUrl: string;
}

export default function InquiryForm({ roleUrl }: InquiryFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);

  const formRef = React.useRef<HTMLFormElement>(null);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    setMessage(null);

    const formData = new FormData(e.currentTarget);
    const inquiryData = {
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      telephone: formData.get('telephone') as string,
      requirements: formData.get('requirements') as string,
      role_url: roleUrl
    };

    try {
      // Submit to Supabase
      const { error: supabaseError } = await supabase
        .from('inquiries')
        .insert([inquiryData]);

      if (supabaseError) throw supabaseError;

      // Submit to Airtable
      await new Promise((resolve, reject) => {
        base('Website leads').create([
          {
            fields: {
              'Name': inquiryData.name,
              'Work Email': inquiryData.email,
              'Telephone': inquiryData.telephone,
              'Requirements': inquiryData.requirements || '',
              'JD URL': inquiryData.role_url,
              'GDPR consent': true
            }
          }
        ], function(err, records) {
          if (err) {
            console.error('Error submitting to Airtable:', err);
            reject(err);
            return;
          }
          resolve(records);
        });
      });

      setMessage({
        type: 'success',
        text: 'Thank you for your inquiry. Our team will get in touch shortly.'
      });
      formRef.current?.reset();
    } catch (error) {
      console.error('Error submitting inquiry:', error);
      setMessage({
        type: 'error',
        text: 'Sorry, there was an error submitting your inquiry. Please try again.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
      <div>
        <input
          type="text"
          name="name"
          placeholder="Name"
          required
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#4353FF] focus:border-transparent"
        />
      </div>
      <div>
        <input
          type="email"
          name="email"
          placeholder="Work Email"
          required
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#4353FF] focus:border-transparent"
        />
      </div>
      <div>
        <input
          type="tel"
          name="telephone"
          placeholder="Telephone"
          required
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#4353FF] focus:border-transparent"
        />
      </div>
      <div>
        <textarea
          name="requirements"
          placeholder="Additional Requirements"
          rows={4}
          className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-[#4353FF] focus:border-transparent"
        />
      </div>
      <div className="flex items-start gap-3">
        <label className="relative inline-flex items-center cursor-pointer">
          <input 
            type="checkbox"
            required
            className="sr-only peer"
          />
          <div className="w-14 h-7 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-[#4353FF]/20 rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#4353FF]"></div>
        </label>
        <label className="text-sm text-gray-600 flex-1">
          I have read and accept the <a href="/privacy" className="text-[#4353FF] hover:text-[#4353FF]/80">YTA Privacy Policy</a>
        </label>
      </div>
      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full px-6 py-3 bg-[#4353FF] text-white font-semibold rounded-lg hover:bg-[#4353FF]/90 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {isSubmitting ? 'Submitting...' : 'Submit Inquiry'}
      </button>
      {message && (
        <div className={`p-4 rounded-lg ${
          message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
        }`}>
          {message.text}
        </div>
      )}
    </form>
  );
}