import type { FAQSection } from '../types/faq';

export const faqSections: FAQSection[] = [
  {
    title: "Traditional Outsourcing vs YTA's Solution",
    questions: [
      {
        question: "How is YTA different from traditional BPO providers?",
        answer: "Unlike traditional BPO providers who assign shared teams across multiple clients, YTA provides dedicated employees who work exclusively for your company. Your team members are fully integrated into your organization, use your systems directly, and follow your processes - just like your local staff. This model eliminates common BPO issues like high turnover, inconsistent quality, and lack of accountability."
      },
      {
        question: "What are the key risks of traditional outsourcing and how does YTA address them?",
        answer: "Traditional outsourcing risks include: data security breaches due to shared infrastructure, high staff turnover affecting quality, lack of direct control over teams, and cultural misalignment. YTA eliminates these risks through: dedicated company-managed devices, direct employment relationships, full integration with your systems and processes, and comprehensive cultural alignment programs."
      },
      {
        question: "How does YTA's pricing model differ from traditional BPOs?",
        answer: "Traditional BPOs often have complex pricing models with hidden costs and markup on every service. YTA offers transparent pricing based on actual employee salaries plus a simple management fee. There are no markups on equipment, software, or additional services. This typically results in 30-40% lower costs compared to traditional BPO arrangements."
      },
      {
        question: "What about intellectual property protection?",
        answer: "Unlike BPOs where teams work across multiple clients, YTA team members work exclusively for you and sign direct NDAs. They use your systems and follow your security protocols, eliminating the risk of IP exposure through shared infrastructure or cross-client contamination. All work is owned directly by your company."
      },
      {
        question: "How does employee retention compare?",
        answer: "Traditional BPOs often have turnover rates of 30-50% annually due to shared resource models and limited career growth. YTA maintains 90%+ retention rates through direct employment relationships, competitive benefits, clear career paths, and full integration with client teams. This ensures knowledge retention and consistent quality."
      }
    ]
  },
  {
    title: "Cultural Integration",
    questions: [
      {
        question: "How do you manage cultural differences between UK and Sri Lankan teams?",
        answer: "We facilitate cultural integration through: regular cross-cultural training sessions, dedicated team building activities, celebration of both UK and Sri Lankan holidays, and structured communication protocols that account for cultural nuances. Our experience shows that cultural diversity often leads to more innovative and effective teams."
      },
      {
        question: "What about time zone differences?",
        answer: "Sri Lanka's time zone (UTC+5:30) provides a significant overlap with UK working hours. Most teams operate on a hybrid schedule with 4-6 hours of overlap for real-time collaboration, while utilizing asynchronous communication tools for other times. This often results in extended coverage and faster project turnaround."
      },
      {
        question: "How do you ensure effective communication across cultures?",
        answer: "We implement clear communication frameworks including: regular video meetings, documented communication protocols, use of collaboration tools, and cultural awareness training. Our Sri Lankan team members are fluent in English and experienced in working with UK businesses."
      },
      {
        question: "What support do you provide for team integration?",
        answer: "We provide comprehensive integration support including: cultural orientation sessions for both UK and Sri Lankan team members, communication guidelines, team building activities, and regular feedback sessions. A dedicated success manager helps facilitate smooth cross-cultural collaboration."
      },
      {
        question: "How do you handle different working styles?",
        answer: "We focus on creating a balanced work environment that respects both cultures while maintaining professional standards. This includes clear documentation of expectations, regular alignment meetings, and flexibility in adapting processes to suit both teams' working styles."
      }
    ]
  },
  {
    title: "GDPR & Data Protection",
    questions: [
      {
        question: "How do you ensure GDPR compliance with offshore teams?",
        answer: "We implement comprehensive GDPR compliance measures including: dedicated equipment and infrastructure for each client, strict data access controls, company-managed devices with enterprise-grade security, regular GDPR training for staff, and detailed Data Processing Agreements (DPAs). Unlike traditional BPO models, our dedicated team approach ensures your data is handled exclusively by your assigned staff."
      },
      {
        question: "What security measures are in place for data protection?",
        answer: "We maintain robust security measures including: encrypted data transmission and storage, secure company-managed laptops with endpoint protection, role-based access control, regular security audits, and strict policies prohibiting personal device usage for work. Staff access your existing cloud infrastructure directly, eliminating the need for additional data transfers or third-party tools."
      },
      {
        question: "How do you handle data processing agreements?",
        answer: "We provide comprehensive Data Processing Agreements (DPAs) that clearly outline roles, responsibilities, and data handling procedures in compliance with GDPR Article 28. Our DPAs include specific provisions for international data transfers, data minimization, and security measures."
      },
      {
        question: "What training do offshore staff receive regarding GDPR?",
        answer: "All team members undergo mandatory GDPR training covering: data protection principles, security protocols, breach reporting procedures, and handling of personal data. Training is customized to your specific requirements and regularly updated to reflect the latest regulations."
      },
      {
        question: "How do you handle data transfer between UK and offshore locations?",
        answer: "Data transfers are minimized as offshore staff use the same cloud networks and tools used by onshore staff, without any YTA-provided software. For any minimal data transfers needed, we ensure GDPR compliance through Standard Contractual Clauses (SCCs), encrypted transmission channels, secure VPN connections, and documented data flow processes. All transfers are monitored and logged for audit purposes."
      }
    ]
  },
  {
    title: "Workforce Planning",
    questions: [
      {
        question: "How do you help with workforce capacity planning?",
        answer: "We assist in analyzing your current and future workforce needs, identifying skill gaps, and developing a strategic plan to scale your offshore team efficiently. This includes workload analysis, skill mapping, and growth projections."
      },
      {
        question: "What is the recommended timeline for workforce expansion?",
        answer: "We typically recommend a phased approach over 3-6 months for optimal team integration. This allows for proper onboarding, training, and cultural alignment while maintaining operational efficiency."
      },
      {
        question: "How do you handle seasonal workforce fluctuations?",
        answer: "We offer flexible team scaling options to accommodate seasonal demands. Our model allows for both temporary team expansion and reduction while maintaining core team stability."
      },
      {
        question: "What metrics do you use for workforce planning?",
        answer: "We track key metrics including productivity rates, utilization levels, skill distribution, and growth projections to ensure optimal team composition and performance."
      }
    ]
  },
  {
    title: "Recruitment",
    questions: [
      {
        question: "How do you source candidates for offshore roles?",
        answer: "We have a well-established employer brand in Sri Lanka that attracts top talent, including our proprietary job board with over 15,000 monthly visitors. Combined with our extensive referral network and pre-existing talent pool from sourcing for multiple clients in parallel, we maintain a vibrant and diverse candidate pipeline. We carefully match candidates based on skills, experience, and cultural fit for your company."
      },
      {
        question: "What is the typical timeframe for recruitment?",
        answer: "We typically see successful candidates within two weeks of starting the search. Most candidates have a 4-week notice period with their current employer, making the total recruitment timeline around 6 weeks. For high-demand technical roles and senior positions where notice periods can extend to 8 weeks, the timeline may be longer."
      },
      {
        question: "Do you offer support for background checks?",
        answer: "Yes, we provide comprehensive background checks, including employment history, education verification, and criminal records, where applicable."
      },
      {
        question: "Can you help with recruitment for niche roles?",
        answer: "Absolutely. Our team specializes in finding talent for even the most niche roles across various industries."
      }
    ]
  },
  {
    title: "Onboarding",
    questions: [
      {
        question: "What does the onboarding process include?",
        answer: "The onboarding process includes training on your company's systems and processes, orientation on role expectations, and cultural integration sessions."
      },
      {
        question: "How do you ensure offshore employees are ready to start?",
        answer: "We ensure they are equipped with the required tools, systems access, and training before their start date."
      },
      {
        question: "Can onboarding materials be customized for my company?",
        answer: "Yes, we work closely with you to incorporate your company's specific onboarding materials and requirements."
      }
    ]
  },
  {
    title: "Payroll",
    questions: [
      {
        question: "How is payroll managed for offshore teams?",
        answer: "We handle payroll processing, ensuring compliance with local laws, including tax deductions and statutory contributions."
      },
      {
        question: "Can you accommodate variable pay structures?",
        answer: "Yes, we support fixed salaries, performance-based pay, and bonuses as per your requirements."
      },
      {
        question: "How are currency fluctuations managed in payroll?",
        answer: "We set all contracts in the clients paying currency so that there is no fluctuation in monthly billing. Offshore employees prefer this as well as local currencies in developing countries are volatile and tend to depreciate over time."
      }
    ]
  },
  {
    title: "Performance",
    questions: [
      {
        question: "How do you track employee performance?",
        answer: "We set KPIs during onboarding and monitor them regularly through performance reviews and management tools."
      },
      {
        question: "Can you help with performance improvement plans?",
        answer: "Yes, we assist in creating and implementing tailored performance improvement plans if required."
      },
      {
        question: "How do I provide feedback to offshore employees?",
        answer: "You can provide feedback directly, or we can act as an intermediary to deliver feedback constructively."
      }
    ]
  },
  {
    title: "Billing",
    questions: [
      {
        question: "How does your billing process work?",
        answer: "We invoice monthly, detailing employee salaries, equipment costs, and any add-on services you've opted for."
      },
      {
        question: "Are there any upfront costs?",
        answer: "Yes, there's a one-time setup fee which primarily covers equipment provisioning and recruitment costs. This ensures your offshore team member has the necessary tools and infrastructure from day one."
      },
      {
        question: "What payment methods do you accept?",
        answer: "We accept payments in USD (US Dollar), GBP (British Pound), and EUR (Euro) through wire transfers and other electronic payment methods."
      }
    ]
  },
  {
    title: "Support",
    questions: [
      {
        question: "How do you provide support?",
        answer: "We provide comprehensive support during UK business hours (9am to 5pm Monday to Friday) with limited support over weekends for handling urgent issues. Our support includes HR, IT, and operational assistance for your offshore team."
      },
      {
        question: "Who do I contact for urgent issues?",
        answer: "Each client is assigned a dedicated account manager who acts as the first point of contact for any concerns."
      },
      {
        question: "Do you provide 24/7 support?",
        answer: "While our primary support is during UK business hours, we maintain weekend coverage for urgent matters to ensure critical issues are addressed promptly outside regular hours."
      }
    ]
  }
];