// @ts-check
import { defineConfig } from 'astro/config'
import tailwind from '@astrojs/tailwind'
import react from '@astrojs/react'
import sitemap from '@astrojs/sitemap'

const SITE_URL = 'https://yourteaminasia.co.uk'

export default defineConfig({
  integrations: [
    tailwind(),
    react(),
    sitemap()
  ],
  site: SITE_URL,
  output: 'static',
  build: {
    inlineStylesheets: 'never',
    assets: 'assets'
  },
  server: {
    port: 4321
  },
  vite: {
    build: {
      cssMinify: true,
      assetsInlineLimit: 4096,
      rollupOptions: {
        output: {
          assetFileNames: 'assets/[name].[hash][extname]',
          chunkFileNames: 'assets/[name].[hash].js',
          entryFileNames: 'assets/[name].[hash].js'
        }
      },
      target: 'esnext'
    }
  }
});