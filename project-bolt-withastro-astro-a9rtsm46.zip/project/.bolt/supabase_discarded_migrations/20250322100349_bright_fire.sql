/*
  # Disable RLS on Success Stories Table
  
  1. Changes
    - Disable Row Level Security on success_stories table
    - Drop existing RLS policy
    
  2. Rationale
    - Success stories are public content
    - No need for row-level access control
*/

-- Disable RLS
ALTER TABLE success_stories DISABLE ROW LEVEL SECURITY;

-- Drop existing policy
DROP POLICY IF EXISTS "Allow public read access to success stories" ON success_stories;