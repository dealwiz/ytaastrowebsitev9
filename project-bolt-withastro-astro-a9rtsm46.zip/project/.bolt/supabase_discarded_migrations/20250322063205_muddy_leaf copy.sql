/*
  # Add Blog Tables

  1. New Tables
    - `blog_categories`
      - `id` (text, primary key)
      - `name` (text)
      - `description` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `blog_posts`
      - `id` (text, primary key) 
      - `title` (text)
      - `slug` (text, unique)
      - `excerpt` (text)
      - `content` (text)
      - `category` (text, foreign key)
      - `image_url` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add public read access policies
*/

-- Create blog_categories table
CREATE TABLE blog_categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create blog_posts table
CREATE TABLE blog_posts (
  id text PRIMARY KEY,
  title text NOT NULL,
  slug text UNIQUE NOT NULL,
  excerpt text,
  content text,
  category text REFERENCES blog_categories(id) ON DELETE SET NULL,
  image_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create triggers for updated_at
CREATE TRIGGER update_blog_categories_updated_at
  BEFORE UPDATE ON blog_categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_blog_posts_updated_at
  BEFORE UPDATE ON blog_posts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE blog_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Allow public read access to blog categories"
  ON blog_categories
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow public read access to blog posts"
  ON blog_posts
  FOR SELECT
  TO public
  USING (true);

-- Insert sample data
INSERT INTO blog_categories (id, name, description) VALUES
('offshore-teams', 'Offshore Teams', 'Articles about building and managing offshore teams'),
('remote-work', 'Remote Work', 'Insights about remote work practices and culture'),
('technology', 'Technology', 'Latest technology trends and best practices');

INSERT INTO blog_posts (id, title, slug, excerpt, content, category, image_url, created_at) VALUES
('1', 'Building Successful Offshore Teams', 'building-successful-offshore-teams', 
'Learn the key strategies for building and managing successful offshore teams.', 
'Full article content about building offshore teams...', 
'offshore-teams',
'https://images.unsplash.com/photo-1522071820081-009f0129c71c',
now() - interval '2 days'),

('2', 'Remote Work Best Practices', 'remote-work-best-practices',
'Discover proven best practices for effective remote work collaboration.', 
'Full article content about remote work practices...', 
'remote-work',
'https://images.unsplash.com/photo-1521898284481-a5ec348cb555',
now() - interval '1 day'),

('3', 'Technology Trends 2024', 'technology-trends-2024',
'Explore the latest technology trends shaping the future of work.', 
'Full article content about technology trends...', 
'technology',
'https://images.unsplash.com/photo-1518770660439-4636190af475',
now());