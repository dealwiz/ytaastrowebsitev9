/*
  # Add Legal Admin Category and Role

  1. Changes
    - Add legal-admin category
    - Add legal admin assistant role for social care
    
  Notes:
    - Ensures category exists before adding role
    - Uses DO block for safe category creation
*/

-- First ensure the legal-admin category exists
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM categories WHERE id = 'legal-admin') THEN
    INSERT INTO categories (id, name, description)
    VALUES ('legal-admin', 'Legal Admin', 'Legal administrative professionals supporting compliance and documentation');
  END IF;
END $$;

-- Then add the legal admin assistant role
INSERT INTO roles (
  id,
  title,
  category,
  summary,
  uk_salary_range,
  lk_salary_range,
  key_skills,
  responsibilities
) VALUES (
  'legal-admin-assistant',
  'Legal Admin Assistant',
  'legal-admin',
  'Support legal administrative operations with focus on compliance, documentation, and regulatory requirements.',
  '£25,000 - £35,000',
  '£12,500 - £17,500',
  ARRAY[
    'Legal Documentation',
    'Compliance Support',
    'Contract Administration',
    'Regulatory Knowledge',
    'Document Management',
    'Legal Research',
    'Data Protection'
  ],
  ARRAY[
    'Manage legal documentation and filing systems',
    'Support contract administration and tracking',
    'Assist with compliance documentation',
    'Maintain regulatory records and updates',
    'Handle confidential information securely',
    'Support legal research tasks',
    'Process legal correspondence'
  ]
);