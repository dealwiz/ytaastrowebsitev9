/*
  # Categories and Roles Schema

  1. New Tables
    - `categories`
      - `id` (text, primary key) - e.g., 'finance-accounting', 'virtual-assistants'
      - `name` (text) - e.g., 'Finance & Accounting'
      - `description` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `roles`
      - `id` (text, primary key) - e.g., 'junior-accountant'
      - `category_id` (text, foreign key)
      - `title` (text)
      - `summary` (text)
      - `uk_salary_range_min` (integer)
      - `uk_salary_range_max` (integer)
      - `lk_salary_range_min` (integer)
      - `lk_salary_range_max` (integer)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `role_skills`
      - `id` (uuid, primary key)
      - `role_id` (text, foreign key)
      - `skill` (text)
      - `created_at` (timestamptz)

    - `role_responsibilities`
      - `id` (uuid, primary key)
      - `role_id` (text, foreign key)
      - `responsibility` (text)
      - `created_at` (timestamptz)
*/

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create roles table
CREATE TABLE IF NOT EXISTS roles (
  id text PRIMARY KEY,
  category_id text REFERENCES categories(id) ON DELETE CASCADE,
  title text NOT NULL,
  summary text,
  uk_salary_range_min integer,
  uk_salary_range_max integer,
  lk_salary_range_min integer,
  lk_salary_range_max integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create role_skills table
CREATE TABLE IF NOT EXISTS role_skills (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  role_id text REFERENCES roles(id) ON DELETE CASCADE,
  skill text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create role_responsibilities table
CREATE TABLE IF NOT EXISTS role_responsibilities (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  role_id text REFERENCES roles(id) ON DELETE CASCADE,
  responsibility text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for updated_at
CREATE TRIGGER update_categories_updated_at
  BEFORE UPDATE ON categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_roles_updated_at
  BEFORE UPDATE ON roles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();