/*
  # Initial Schema Setup

  1. New Tables
    - `categories`
      - `id` (text, primary key)
      - `name` (text)
      - `description` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `roles`
      - `id` (text, primary key)
      - `title` (text)
      - `category` (text, foreign key)
      - `summary` (text)
      - `uk_salary_range` (text)
      - `lk_salary_range` (text)
      - `key_skills` (text[])
      - `responsibilities` (text[])
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Functions
    - `update_updated_at_column()`: Trigger function to update updated_at timestamp

  3. Triggers
    - Update triggers for both tables to maintain updated_at
*/

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create categories table
CREATE TABLE categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create roles table
CREATE TABLE roles (
  id text PRIMARY KEY,
  title text NOT NULL,
  category text NOT NULL,
  summary text,
  uk_salary_range text,
  lk_salary_range text,
  key_skills text[] DEFAULT '{}',
  responsibilities text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT fk_category
    FOREIGN KEY (category)
    REFERENCES categories(id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
);

-- Create triggers for updated_at
CREATE TRIGGER update_categories_updated_at
  BEFORE UPDATE ON categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_roles_updated_at
  BEFORE UPDATE ON roles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert initial categories
INSERT INTO categories (id, name, description)
VALUES
  ('finance-accounting', 'Finance & Accounting', 'Financial professionals with expertise in UK accounting standards and practices'),
  ('software-it', 'Software & IT', 'Technical professionals specializing in software development and IT operations'),
  ('hr', 'Human Resources', 'HR professionals experienced in UK employment practices and people management'),
  ('virtual-assistants', 'Virtual Assistants', 'Skilled virtual assistants providing comprehensive administrative and executive support');