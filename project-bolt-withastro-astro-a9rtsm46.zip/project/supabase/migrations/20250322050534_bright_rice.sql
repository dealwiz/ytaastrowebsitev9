/*
  # Insert Remaining Roles Data

  1. Changes
    - Insert all remaining roles from the TypeScript files
    - Includes all software development roles
    - Includes remaining finance roles
    - Preserves array data structure for skills and responsibilities

  Notes:
    - Maintains consistent data format
    - Preserves all role details
*/

INSERT INTO roles (
  id,
  title,
  category,
  category_name,
  category_description,
  summary,
  uk_salary_range,
  lk_salary_range,
  key_skills,
  responsibilities
) VALUES
-- Software Development Roles
(
  'software-engineer',
  'Full Stack Developer',
  'it',
  'Software Development',
  'Technical professionals specializing in software development and IT operations',
  'Build and maintain full stack applications using modern frontend and backend technologies while following best practices.',
  '£45,000 - £65,000',
  '£22,500 - £32,500',
  ARRAY['Full Stack Development', 'JavaScript/TypeScript', 'React/Node.js', 'Database Design', 'RESTful APIs', 'Cloud Services', 'CI/CD'],
  ARRAY['Build and maintain full stack web applications', 'Design and implement database schemas and APIs', 'Write clean, maintainable, and efficient code', 'Collaborate with cross-functional teams', 'Participate in code reviews and technical discussions', 'Troubleshoot and debug applications']
),
(
  'python-developer',
  'Python Developer',
  'it',
  'Software Development',
  'Technical professionals specializing in software development and IT operations',
  'Build and maintain robust Python applications with a focus on data processing, APIs, and backend services.',
  '£45,000 - £65,000',
  '£22,500 - £32,500',
  ARRAY['Python', 'Django/Flask', 'REST APIs', 'SQL/NoSQL', 'Data Processing', 'AWS/Cloud Services', 'Test-Driven Development'],
  ARRAY['Develop and maintain Python applications and services', 'Design and implement RESTful APIs', 'Build efficient data processing pipelines', 'Write clean, testable, and maintainable code', 'Optimize application performance and scalability', 'Collaborate with cross-functional teams on technical solutions']
),
(
  'react-developer',
  'React Developer',
  'it',
  'Software Development',
  'Technical professionals specializing in software development and IT operations',
  'Build modern, responsive web applications using React and related technologies while following best practices and design patterns.',
  '£45,000 - £65,000',
  '£22,500 - £32,500',
  ARRAY['React.js', 'TypeScript', 'Redux/State Management', 'Modern CSS', 'Testing (Jest/RTL)', 'Performance Optimization', 'Component Design'],
  ARRAY['Develop responsive and interactive user interfaces', 'Build reusable components and libraries', 'Optimize application performance and loading times', 'Implement state management solutions', 'Write unit and integration tests', 'Collaborate with designers and backend developers']
),
-- Remaining Finance Roles
(
  'fpa-analyst',
  'FP&A Analyst',
  'finance-accounting',
  'Finance & Accounting',
  'Financial professionals with expertise in UK accounting standards and practices',
  'Drive strategic decision-making through financial planning, analysis, and forecasting while providing key business insights.',
  '£40,000 - £55,000',
  '£20,000 - £27,500',
  ARRAY['Financial Modeling', 'Business Analysis', 'Forecasting', 'Budgeting', 'Data Visualization', 'Advanced Excel'],
  ARRAY['Develop and maintain financial models and forecasts', 'Analyze business performance and identify trends', 'Support budget planning and variance analysis', 'Create insightful financial reports and presentations', 'Collaborate with stakeholders to provide business insights', 'Assist in strategic planning and decision-making']
),
(
  'finance-manager',
  'Finance Manager',
  'finance-accounting',
  'Finance & Accounting',
  'Financial professionals with expertise in UK accounting standards and practices',
  'Lead financial operations and provide strategic insights while ensuring compliance with UK accounting standards.',
  '£45,000 - £65,000',
  '£22,500 - £32,500',
  ARRAY['UK GAAP & IFRS', 'Financial Analysis', 'Management Accounting', 'Budgeting & Forecasting', 'Financial Reporting'],
  ARRAY['Manage day-to-day financial operations', 'Prepare and analyze financial reports', 'Develop and monitor budgets', 'Support strategic decision-making', 'Ensure compliance with accounting standards', 'Supervise finance team members']
),
-- Additional Software Development Roles
(
  'angular-developer',
  'Angular Developer',
  'it',
  'Software Development',
  'Technical professionals specializing in software development and IT operations',
  'Build enterprise-grade web applications using Angular framework and TypeScript while following best practices and design patterns.',
  '£45,000 - £65,000',
  '£22,500 - £32,500',
  ARRAY['Angular', 'TypeScript', 'RxJS', 'NgRx/State Management', 'Unit Testing', 'Angular Material', 'Performance Optimization'],
  ARRAY['Develop scalable Angular applications', 'Create reusable UI components', 'Implement state management solutions', 'Write comprehensive unit tests', 'Optimize application performance', 'Collaborate with backend teams on API integration']
),
(
  'java-developer',
  'Java Developer',
  'it',
  'Software Development',
  'Technical professionals specializing in software development and IT operations',
  'Build robust enterprise applications using Java and related technologies while ensuring high performance and scalability.',
  '£45,000 - £65,000',
  '£22,500 - £32,500',
  ARRAY['Java', 'Spring Boot', 'Microservices', 'JPA/Hibernate', 'RESTful APIs', 'SQL/NoSQL', 'Unit Testing', 'CI/CD'],
  ARRAY['Develop enterprise Java applications', 'Design and implement microservices', 'Build scalable backend services', 'Write clean, maintainable code', 'Create comprehensive test suites', 'Optimize application performance']
),
(
  'wordpress-developer',
  'WordPress Developer',
  'it',
  'Software Development',
  'Technical professionals specializing in software development and IT operations',
  'Build and maintain custom WordPress solutions including themes, plugins, and integrations while following best practices and security standards.',
  '£35,000 - £55,000',
  '£17,500 - £27,500',
  ARRAY['WordPress Development', 'PHP', 'Custom Theme Development', 'Plugin Development', 'WooCommerce', 'JavaScript/jQuery', 'MySQL', 'REST API', 'Security Best Practices'],
  ARRAY['Develop custom WordPress themes and plugins', 'Create and maintain e-commerce solutions using WooCommerce', 'Implement security best practices and optimizations', 'Build custom integrations and APIs', 'Ensure mobile responsiveness and cross-browser compatibility', 'Optimize site performance and loading times']
),
(
  'php-developer',
  'PHP Developer',
  'it',
  'Software Development',
  'Technical professionals specializing in software development and IT operations',
  'Build and maintain robust PHP applications with a focus on backend services, APIs, and database integration.',
  '£40,000 - £60,000',
  '£20,000 - £30,000',
  ARRAY['PHP 8.x', 'Laravel/Symfony', 'RESTful APIs', 'MySQL/PostgreSQL', 'Unit Testing', 'MVC Architecture', 'Composer', 'Git', 'Docker'],
  ARRAY['Develop scalable PHP applications using modern frameworks', 'Design and implement database architectures', 'Create and maintain RESTful APIs', 'Write clean, maintainable, and well-documented code', 'Implement security best practices and data protection', 'Collaborate with frontend developers on API integration']
);