/*
  # Add Finance Assistant - Social Care Role

  1. New Role
    - Title: Finance Assistant - Social Care
    - Category: finance-accounting
    - Specialized role for social care sector
    - Includes detailed responsibilities and skills

  Notes:
    - Maintains existing schema structure
    - Includes comprehensive skill set for social care finance
*/

INSERT INTO roles (
  id,
  title,
  category,
  summary,
  uk_salary_range,
  lk_salary_range,
  key_skills,
  responsibilities
) VALUES (
  'finance-assistant-social-care',
  'Finance Assistant - Social Care',
  'finance-accounting',
  'Support financial operations in social care settings with focus on care-specific requirements like funding management, care package invoicing, and local authority billing.',
  '£24,000 - £32,000',
  '£12,000 - £16,000',
  ARRAY[
    'Care Package Invoicing',
    'Local Authority Billing',
    'Funding Management',
    'Financial Administration',
    'Care Management Systems',
    'Excel/Spreadsheets',
    'Social Care Compliance',
    'Cost Analysis'
  ],
  ARRAY[
    'Process care package invoices and funding claims',
    'Manage local authority and CCG billing cycles',
    'Handle resident/service user financial records',
    'Support care funding applications and tracking',
    'Assist with care cost analysis and reporting',
    'Maintain accurate financial records for CQC compliance',
    'Process staff expenses and petty cash for care homes',
    'Support budget management for care services'
  ]
);