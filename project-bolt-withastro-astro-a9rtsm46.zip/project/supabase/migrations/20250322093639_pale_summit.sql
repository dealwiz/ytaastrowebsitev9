/*
  # Add success stories table

  1. New Tables
    - `success_stories`
      - `id` (text, primary key)
      - `role` (text)
      - `company` (text) 
      - `department` (text)
      - `industry` (text)
      - `candidate_name` (text)
      - `location` (text)
      - `image_url` (text)
      - `testimonial` (text)
      - `impact` (text[])
      - `skills` (text[])
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `success_stories` table
    - Add policy for public read access
*/

-- Create success stories table
CREATE TABLE success_stories (
  id text PRIMARY KEY,
  role text NOT NULL,
  company text NOT NULL,
  department text NOT NULL,
  industry text NOT NULL,
  candidate_name text NOT NULL,
  location text NOT NULL,
  image_url text NOT NULL,
  testimonial text NOT NULL,
  impact text[] DEFAULT '{}',
  skills text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create trigger for updated_at
CREATE TRIGGER update_success_stories_updated_at
  BEFORE UPDATE ON success_stories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE success_stories ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Allow public read access to success stories"
  ON success_stories
  FOR SELECT
  TO public
  USING (true);

-- Insert sample data
INSERT INTO success_stories (
  id,
  role,
  company,
  department,
  industry,
  candidate_name,
  location,
  image_url,
  testimonial,
  impact,
  skills
) VALUES
(
  'hasitha-swarnasinghe',
  'Software Project Manager',
  'The GP Service',
  'IT',
  'Healthcare Technology',
  'Hasitha Swarnasinghe',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/hasitha-swarnasinghe-yta/',
  'Working with The GP Service has been an incredible journey. As a Software Project Manager, I''ve had the opportunity to shape the future of healthcare technology while working from Sri Lanka. YTA made this possible by connecting me with a company that truly values innovation and diverse perspectives.',
  ARRAY[
    'Lead product strategy and roadmap development',
    'Drive feature prioritization and delivery',
    'Coordinate between development and business teams'
  ],
  ARRAY[
    'Product Strategy',
    'Agile Management',
    'Healthcare Technology'
  ]
),
(
  'danika-rathnayake',
  'Lead Software Engineer',
  'Care Hires',
  'IT',
  'Care Workforce Management',
  'Danika Rathnayake',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/eranga-wijesekara-yta/',
  'Leading the engineering team at Care Hires has been incredibly rewarding. We''re building solutions that directly impact healthcare staffing efficiency in the UK. YTA''s support in connecting me with this opportunity has been invaluable.',
  ARRAY[
    'Architect and implement scalable solutions',
    'Lead technical strategy and innovation',
    'Mentor and grow engineering team'
  ],
  ARRAY[
    'Software Architecture',
    'Team Leadership',
    'Healthcare Systems'
  ]
);