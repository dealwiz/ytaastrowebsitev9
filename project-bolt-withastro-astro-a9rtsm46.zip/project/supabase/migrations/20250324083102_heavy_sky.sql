/*
  # Add client description to case studies

  1. Changes
    - Add client_description column to case_studies table
    - Update existing records with descriptions
    
  2. Purpose
    - Store brief descriptions about each client company
    - Provide context about the client's business
*/

-- Add the new column
ALTER TABLE case_studies 
ADD COLUMN client_description text;

-- Update existing records with descriptions
UPDATE case_studies 
SET client_description = 'Leading healthcare workforce management platform helping NHS trusts and care homes efficiently manage their temporary staffing needs.'
WHERE client_name = 'Care Hires';

UPDATE case_studies 
SET client_description = 'Digital healthcare provider offering online GP consultations, prescriptions, and healthcare services across the UK.'
WHERE client_name = 'GP Service';