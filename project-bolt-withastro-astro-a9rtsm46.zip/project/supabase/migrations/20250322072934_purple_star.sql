/*
  # Enable RLS and Add Policies for Roles Table

  1. Security Changes
    - Enable RLS on roles table
    - Add public read access policy
    - Add authenticated user policies for CRUD operations

  2. Notes
    - Maintains existing table structure and relationships
    - Adds secure access controls
*/

-- Enable RLS on roles table
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow public read access to roles"
  ON roles
  FOR SELECT
  TO public
  USING (true);

-- Create policy for authenticated users to manage roles
CREATE POLICY "Allow authenticated users to manage roles"
  ON roles
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);