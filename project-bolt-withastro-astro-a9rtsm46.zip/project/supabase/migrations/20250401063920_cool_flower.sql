/*
  # Add Virtual Assistant - Social Care Role

  1. New Role
    - Title: Virtual Assistant - Social Care
    - Category: virtual assistants
    - Includes mixed skills across HR, marketing and finance
*/

INSERT INTO roles (
  id,
  title,
  category,
  summary,
  uk_salary_range,
  lk_salary_range,
  key_skills,
  responsibilities
) VALUES (
  'virtual-assistant-social-care',
  'Virtual Assistant - Social Care',
  'virtual-assistants',
  'Provide comprehensive administrative support across HR, marketing, and finance functions in social care settings while ensuring compliance with care sector requirements.',
  '£24,000 - £34,000',
  '£11,500 - £16,500',
  ARRAY[
    'HR Administration',
    'Social Media Management',
    'Financial Record Keeping',
    'Care Sector Compliance',
    'Marketing Support',
    'Document Management',
    'CQC Documentation'
  ],
  ARRAY[
    'Support HR processes including recruitment and onboarding documentation',
    'Manage social media content and engagement for care services',
    'Process basic financial records and invoice management',
    'Maintain CQC-compliant documentation and filing systems',
    'Assist with marketing campaigns and resident communications',
    'Handle administrative aspects of care quality monitoring',
    'Support budget tracking and financial reporting'
  ]
);