/*
  # Add price range text to categories

  1. Changes
    - Add price_range_text column to categories table
    - Update existing categories with price ranges
    
  Notes:
    - Maintains existing schema structure
    - Includes default pricing for each category
*/

-- Add price_range_text column
ALTER TABLE categories
ADD COLUMN price_range_text text NOT NULL DEFAULT 'From £985/month';

-- Update categories with specific price ranges
UPDATE categories 
SET price_range_text = 'From £1,200/month'
WHERE id = 'finance-accounting';

UPDATE categories 
SET price_range_text = 'From £2,000/month'
WHERE id = 'software-development';

UPDATE categories 
SET price_range_text = 'From £1,100/month'
WHERE id = 'hr';

UPDATE categories 
SET price_range_text = 'From £985/month'
WHERE id = 'virtual-assistants';

UPDATE categories 
SET price_range_text = 'From £1,500/month'
WHERE id = 'it-operations';

UPDATE categories 
SET price_range_text = 'From £1,200/month'
WHERE id = 'marketing';