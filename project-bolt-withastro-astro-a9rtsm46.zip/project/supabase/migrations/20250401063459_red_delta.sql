/*
  # Add HR Assistant - Social Care Role

  1. New Role
    - Title: HR Assistant - Social Care
    - Category: HR operations
    - Includes specialized skills and responsibilities for social care HR
*/

INSERT INTO roles (
  id,
  title,
  category,
  summary,
  uk_salary_range,
  lk_salary_range,
  key_skills,
  responsibilities
) VALUES (
  'hr-assistant-social-care',
  'HR Assistant - Social Care',
  'hr',
  'Support HR operations in social care settings with focus on recruitment, compliance, and employee relations while ensuring CQC standards are met.',
  '£24,000 - £34,000',
  '£11,500 - £16,500',
  ARRAY[
    'Care Sector HR',
    'CQC Compliance',
    'Employee Relations',
    'Recruitment Support',
    'HR Documentation',
    'Training Administration',
    'HRIS Systems'
  ],
  ARRAY[
    'Support recruitment and onboarding in care settings',
    'Maintain employee records and CQC documentation',
    'Assist with training coordination and compliance',
    'Process HR documentation and contracts',
    'Support employee relations and engagement',
    'Help manage DBS checks and certifications',
    'Assist with HR reporting and analytics'
  ]
);