/*
  # Add IT Operations Roles (Fixed)
  
  1. New Roles
    - Add dedicated IT operations roles
    - Check for existing records before insert
    - Include comprehensive skills and responsibilities
*/

DO $$
BEGIN
  -- IT Support Engineer
  IF NOT EXISTS (SELECT 1 FROM roles WHERE id = 'it-support-engineer') THEN
    INSERT INTO roles (
      id,
      title,
      category,
      summary,
      uk_salary_range,
      lk_salary_range,
      key_skills,
      responsibilities
    ) VALUES (
      'it-support-engineer',
      'IT Support Engineer',
      'it-operations',
      'Provide comprehensive IT support and maintain infrastructure while ensuring system reliability and performance.',
      '£35,000 - £50,000',
      '£17,500 - £25,000',
      ARRAY[
        'Windows Server',
        'Active Directory',
        'Network Administration',
        'IT Security',
        'Cloud Infrastructure',
        'Troubleshooting',
        'System Monitoring'
      ],
      ARRAY[
        'Provide technical support for IT infrastructure',
        'Manage and maintain Windows servers and workstations',
        'Handle network administration and security',
        'Monitor system performance and reliability',
        'Implement IT security best practices',
        'Manage cloud infrastructure and services'
      ]
    );
  END IF;

  -- System Administrator
  IF NOT EXISTS (SELECT 1 FROM roles WHERE id = 'system-administrator') THEN
    INSERT INTO roles (
      id,
      title,
      category,
      summary,
      uk_salary_range,
      lk_salary_range,
      key_skills,
      responsibilities
    ) VALUES (
      'system-administrator',
      'System Administrator',
      'it-operations',
      'Manage and maintain IT systems while ensuring optimal performance, security, and reliability.',
      '£40,000 - £60,000',
      '£20,000 - £30,000',
      ARRAY[
        'Linux Administration',
        'Windows Server',
        'Network Security',
        'Cloud Services',
        'Infrastructure Management',
        'Automation',
        'Monitoring Tools'
      ],
      ARRAY[
        'Maintain and optimize system infrastructure',
        'Manage server deployments and configurations',
        'Implement security policies and procedures',
        'Monitor system performance and availability',
        'Automate routine maintenance tasks',
        'Provide technical documentation'
      ]
    );
  END IF;

  -- Network Engineer
  IF NOT EXISTS (SELECT 1 FROM roles WHERE id = 'network-engineer') THEN
    INSERT INTO roles (
      id,
      title,
      category,
      summary,
      uk_salary_range,
      lk_salary_range,
      key_skills,
      responsibilities
    ) VALUES (
      'network-engineer',
      'Network Engineer',
      'it-operations',
      'Design, implement and maintain network infrastructure while ensuring optimal performance and security.',
      '£45,000 - £65,000',
      '£22,500 - £32,500',
      ARRAY[
        'Network Design',
        'Cisco Technologies',
        'Network Security',
        'VPN',
        'Firewall Management',
        'VOIP',
        'Network Monitoring'
      ],
      ARRAY[
        'Design and implement network solutions',
        'Configure and maintain network equipment',
        'Manage network security and access',
        'Monitor network performance',
        'Troubleshoot network issues',
        'Provide technical documentation'
      ]
    );
  END IF;
END $$;