/*
  # Add Personal Assistant Role

  1. New Roles
    - Personal Assistant (PA) role added to virtual-assistants category
    
  Notes:
    - Includes comprehensive skill set for personal assistance
    - Salary ranges aligned with market standards
*/

INSERT INTO roles (
  id,
  title,
  category,
  summary,
  uk_salary_range,
  lk_salary_range,
  key_skills,
  responsibilities,
  category_description
) VALUES (
  'personal-assistant',
  'Personal Assistant (PA)',
  'virtual-assistants',
  'Provide comprehensive personal and professional support while managing daily tasks, schedules, and communications effectively.',
  '£30,000 - £45,000',
  '£15,000 - £22,500',
  ARRAY[
    'Schedule Management',
    'Email & Communications',
    'Personal Task Management',
    'Travel Planning',
    'Document Organization',
    'Basic Bookkeeping',
    'Microsoft Office'
  ],
  ARRAY[
    'Manage personal and professional schedules',
    'Handle correspondence and communications',
    'Organize personal and business tasks',
    'Book travel and accommodation',
    'Maintain filing systems and records',
    'Process basic financial documents and expenses'
  ],
  'Skilled virtual assistants providing comprehensive administrative and executive support'
);