/*
  # Update categories for IT roles

  1. Changes
    - Add new categories for IT roles
    - Update existing roles to use correct categories
    - Ensure consistent mapping between footer links and database
*/

-- First create new categories if they don't exist
INSERT INTO categories (id, name, description)
VALUES
  ('it-operations', 'IT Operations', 'IT operations and infrastructure management professionals'),
  ('software-development', 'Software Development', 'Software development and engineering professionals')
ON CONFLICT (id) DO NOTHING;

-- Update roles to use correct categories
UPDATE roles 
SET category = 'it-operations'
WHERE category = 'software-it' 
AND title ILIKE '%operations%';

UPDATE roles 
SET category = 'software-development'
WHERE category = 'software-it'
AND title NOT ILIKE '%operations%';