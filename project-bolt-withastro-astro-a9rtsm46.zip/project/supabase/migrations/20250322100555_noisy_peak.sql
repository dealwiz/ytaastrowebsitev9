/*
  # Add Success Stories Data
  
  1. Insert Data
    - Add all success stories with complete information
    - Includes roles, companies, testimonials, and skills
*/

INSERT INTO success_stories (
  id,
  role,
  company,
  department,
  industry,
  candidate_name,
  location,
  image_url,
  testimonial,
  impact,
  skills
) VALUES
(
  'hasitha-swarnasinghe',
  'Software Project Manager',
  'The GP Service',
  'IT',
  'Healthcare Technology',
  'Hasitha Swarnasinghe',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/hasitha-swarnasinghe-yta/',
  'Working with The GP Service has been an incredible journey. As a Software Project Manager, I''ve had the opportunity to shape the future of healthcare technology while working from Sri Lanka. YTA made this possible by connecting me with a company that truly values innovation and diverse perspectives.',
  ARRAY[
    'Lead product strategy and roadmap development',
    'Drive feature prioritization and delivery',
    'Coordinate between development and business teams'
  ],
  ARRAY[
    'Product Strategy',
    'Agile Management',
    'Healthcare Technology'
  ]
),
(
  'danika-rathnayake',
  'Lead Software Engineer',
  'Care Hires',
  'IT',
  'Care Workforce Management',
  'Danika Rathnayake',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/eranga-wijesekara-yta/',
  'Leading the engineering team at Care Hires has been incredibly rewarding. We''re building solutions that directly impact healthcare staffing efficiency in the UK. YTA''s support in connecting me with this opportunity has been invaluable.',
  ARRAY[
    'Architect and implement scalable solutions',
    'Lead technical strategy and innovation',
    'Mentor and grow engineering team'
  ],
  ARRAY[
    'Software Architecture',
    'Team Leadership',
    'Healthcare Systems'
  ]
),
(
  'ishan-almeda',
  'Customer Support Manager',
  'Care Hires',
  'Customer Support',
  'Care Workforce Management',
  'Ishan Almeda',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/ishan-almeda-yta/',
  'Managing customer support for Care Hires has allowed me to make a real difference in healthcare staffing operations. YTA helped me find a role where I can lead a team that directly impacts healthcare delivery in the UK.',
  ARRAY[
    'Lead customer support strategy',
    'Implement support processes and standards',
    'Drive customer satisfaction improvements'
  ],
  ARRAY[
    'Customer Support',
    'Team Management',
    'Healthcare Operations'
  ]
),
(
  'hasitha-chandula',
  'Lead Software Engineer',
  'Block Solutions',
  'IT',
  'IT Solutions',
  'Hasitha Chandula',
  'Offshore (Sri Lanka → UK)',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7',
  'Working with Block Solutions has been an exciting journey in innovative IT solutions. YTA connected me with a company that values technical excellence and allows me to lead impactful projects from Sri Lanka.',
  ARRAY[
    'Lead technical architecture and development',
    'Drive innovation and best practices',
    'Mentor development team members'
  ],
  ARRAY[
    'Software Architecture',
    'Technical Leadership',
    'Solution Design'
  ]
),
(
  'praveena-selvakumar',
  'Finance Executive',
  'Reim Capital',
  'Finance',
  'Financial Services',
  'Praveena Selvakumar',
  'Offshore (Sri Lanka → UK)',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
  'YTA connected me with an opportunity at Reim Capital that perfectly matches my financial expertise. I''m able to contribute to a leading UK financial services firm while working from Sri Lanka.',
  ARRAY[
    'Handle financial operations and reporting',
    'Manage accounts and reconciliations',
    'Support financial decision-making'
  ],
  ARRAY[
    'Financial Operations',
    'Reporting',
    'Analysis'
  ]
),
(
  'salman-faiz',
  'Marketing Manager',
  'The GP Service',
  'Marketing',
  'Private Healthcare',
  'Salman Faiz',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/salman-faiz-yta/',
  'Leading marketing initiatives for The GP Service has been incredibly rewarding. YTA helped me find a role where I can drive healthcare marketing innovation while working from Sri Lanka.',
  ARRAY[
    'Develop and execute marketing strategies',
    'Lead digital campaigns and initiatives',
    'Drive patient engagement and growth'
  ],
  ARRAY[
    'Healthcare Marketing',
    'Digital Strategy',
    'Campaign Management'
  ]
),
(
  'shakila-piumani',
  'EA to CEO',
  'The GP Service',
  'Secretarial',
  'Private Healthcare',
  'Shakila Piumani',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/sahkila-piumani-yta/',
  'Working as an Executive Assistant at The GP Service has been an amazing opportunity to support healthcare leadership. YTA helped me find a role where I can utilize my organizational skills effectively.',
  ARRAY[
    'Manage executive calendar and communications',
    'Coordinate high-level meetings and events',
    'Handle confidential information'
  ],
  ARRAY[
    'Executive Support',
    'Calendar Management',
    'Communication'
  ]
),
(
  'anuththara-senadeera',
  'Onboarding & Compliance Manager',
  'IBC Healthcare',
  'HR',
  'Care Provider',
  'Anuththara Senadeera',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/anuththara-senadheera-yta/',
  'Managing onboarding and compliance for IBC Healthcare allows me to ensure quality care delivery through proper staff management. YTA connected me with a role where I can make a real difference in healthcare operations.',
  ARRAY[
    'Oversee staff onboarding processes',
    'Ensure compliance with healthcare regulations',
    'Manage HR documentation and records'
  ],
  ARRAY[
    'HR Operations',
    'Healthcare Compliance',
    'Process Management'
  ]
),
(
  'romain-sovis',
  'PA to CEO',
  'Reim Capital',
  'Secretarial',
  'Financial Services',
  'Romain Sovis',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/maryse-nawaratne-yta/',
  'Supporting the CEO of Reim Capital has been a fantastic opportunity to work in financial services at a strategic level. YTA helped me find a role where I can utilize my skills to support executive leadership effectively.',
  ARRAY[
    'Manage executive communications',
    'Coordinate strategic meetings',
    'Handle confidential matters'
  ],
  ARRAY[
    'Executive Support',
    'Financial Services',
    'Communication'
  ]
),
(
  'kaveesha-gimhana',
  'Software Engineer',
  'Care Hires',
  'IT',
  'Care Workforce Management',
  'Kaveesha Gimhana',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/eranga-wijesekara-yta/',
  'Being part of Care Hires'' engineering team has been an incredible opportunity to develop innovative solutions for healthcare workforce management. YTA connected me with a role where I can grow technically while making a meaningful impact in healthcare operations.',
  ARRAY[
    'Develop and maintain core platform features',
    'Implement scalable software solutions',
    'Collaborate with cross-functional teams'
  ],
  ARRAY[
    'Full Stack Development',
    'Healthcare Systems',
    'Agile Development'
  ]
),
(
  'eranga-wijesekara',
  'Admin - Support',
  'The GP Service',
  'Customer Support',
  'Private Healthcare',
  'Eranga Wijesekara',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/eranga-wijesekara-yta/',
  'Supporting The GP Service''s administrative operations has been a rewarding experience. YTA connected me with a role where I can contribute to healthcare service delivery while working with a dedicated team focused on patient care.',
  ARRAY[
    'Manage administrative support operations',
    'Handle patient documentation and records',
    'Coordinate with healthcare providers'
  ],
  ARRAY[
    'Healthcare Administration',
    'Patient Support',
    'Documentation Management'
  ]
),
(
  'dineth-yapa',
  'Finance Assistant',
  'Block Solutions',
  'Finance',
  'IT Solutions',
  'Dineth Yapa',
  'Offshore (Sri Lanka → UK)',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7',
  'Working with Block Solutions has given me valuable experience in managing financial operations for a dynamic IT company. YTA helped me find a role where I can grow my finance career while working with an innovative UK tech firm.',
  ARRAY[
    'Process financial transactions and reconciliations',
    'Support month-end closing procedures',
    'Assist with financial reporting and analysis'
  ],
  ARRAY[
    'Financial Operations',
    'Accounting',
    'Financial Reporting'
  ]
),
(
  'niroshan-de-silva',
  'Senior Software Engineer - Test Automation',
  'Care Hires',
  'IT',
  'IT Solutions',
  'Niroshan De Silva',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/niroshan-de-silva-yta/',
  'Leading test automation at Care Hires has enabled me to establish robust quality assurance practices that ensure reliable software delivery. YTA connected me with a role where I can drive innovation in testing methodologies.',
  ARRAY[
    'Design and implement test automation frameworks',
    'Lead QA strategy and best practices',
    'Mentor QA team members'
  ],
  ARRAY[
    'Test Automation',
    'CI/CD',
    'Quality Assurance'
  ]
),
(
  'mahima-induwara',
  'Senior WordPress Developer',
  'Taxien LLC',
  'IT',
  'IT Solutions',
  'Mahima Induwara',
  'Offshore (Sri Lanka → USA)',
  'https://cms.yourteaminasia.com/mahima-induwara-yta/',
  'Working with Taxien LLC has allowed me to push the boundaries of WordPress development. YTA helped me find a role where I can create innovative solutions while working with a global team.',
  ARRAY[
    'Lead WordPress development initiatives',
    'Optimize website performance',
    'Implement custom plugins and themes'
  ],
  ARRAY[
    'WordPress',
    'PHP',
    'Frontend Development'
  ]
),
(
  'faward-razeek',
  'Senior Finance Executive',
  'Care Hires',
  'Finance',
  'IT Solutions',
  'Faward Razeek',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/fawaad-razeek-yta/',
  'Managing financial operations for Care Hires has been a rewarding experience. YTA connected me with an opportunity where I can apply my expertise in a dynamic tech environment.',
  ARRAY[
    'Oversee financial reporting and analysis',
    'Manage budgeting and forecasting',
    'Drive financial process improvements'
  ],
  ARRAY[
    'Financial Analysis',
    'Budgeting',
    'Process Optimization'
  ]
),
(
  'madushani-nanayakkara',
  'Onboarding Team Lead',
  'IBC Healthcare',
  'HR',
  'Private Healthcare',
  'Madushani Nanayakkara',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/madhushani-nanayakkara-yta/',
  'Leading the onboarding team at IBC Healthcare allows me to ensure smooth integration of new staff while maintaining high standards of compliance. YTA helped me find a role where I can make a real impact in healthcare operations.',
  ARRAY[
    'Lead onboarding process improvements',
    'Ensure compliance with healthcare regulations',
    'Manage team performance and development'
  ],
  ARRAY[
    'HR Operations',
    'Healthcare Compliance',
    'Team Leadership'
  ]
),
(
  'leena-sadeera',
  'Learning & Development Executive',
  'IBC Healthcare',
  'HR',
  'Private Healthcare',
  'Leena Sadeera',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/leena-sadeera-yta/',
  'Developing training programs for healthcare professionals at IBC Healthcare has been incredibly fulfilling. YTA connected me with a role where I can contribute to professional growth in healthcare.',
  ARRAY[
    'Design and deliver training programs',
    'Develop learning materials',
    'Track training effectiveness'
  ],
  ARRAY[
    'Training Design',
    'Healthcare Education',
    'Program Management'
  ]
),
(
  'peruka-gunawardena',
  'Associate Project Manager',
  'Taxien LLC',
  'IT',
  'Enterprise Software',
  'Peruka Gunawardena',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/peruka-gunawardena-yta/',
  'Working with Taxien LLC has given me the opportunity to manage complex enterprise software projects. YTA connected me with a role where I can leverage my project management skills while working with a global team.',
  ARRAY[
    'Coordinate software development projects',
    'Manage stakeholder communications',
    'Drive project delivery and timelines'
  ],
  ARRAY[
    'Project Management',
    'Agile Methodologies',
    'Enterprise Software'
  ]
),
(
  'maryse-nawaratne',
  'Account Executive',
  'Care Hires',
  'Customer Support',
  'Care Workforce Management',
  'Maryse Nawaratne',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/maryse-nawaratne-yta/',
  'Being an Account Executive at Care Hires allows me to build strong relationships with healthcare providers while ensuring smooth workforce management. YTA connected me with a role where I can make a meaningful impact in the healthcare sector.',
  ARRAY[
    'Manage key client relationships',
    'Drive account growth and retention',
    'Coordinate workforce solutions'
  ],
  ARRAY[
    'Account Management',
    'Healthcare Operations',
    'Client Relations'
  ]
),
(
  'raveen-halawathage',
  'Senior Digital Marketing Executive',
  'Pharmacy Express',
  'Marketing',
  'Private Healthcare',
  'Raveen Halawathage',
  'Offshore (Sri Lanka → UK)',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7',
  'Driving digital marketing initiatives for Pharmacy Express has allowed me to combine healthcare knowledge with marketing expertise. YTA helped me find a role where I can create impactful healthcare marketing campaigns.',
  ARRAY[
    'Lead digital marketing strategies',
    'Manage healthcare campaigns',
    'Analyze marketing performance'
  ],
  ARRAY[
    'Digital Marketing',
    'Healthcare Marketing',
    'Analytics'
  ]
);