/*
  # Add Customer Support Case Study

  1. New Data
    - Add a new case study record for Care Hires' customer support team
    - Includes roles hired, results, and testimonial details
*/

INSERT INTO case_studies (
  id,
  title,
  client_name,
  client_industry,
  roles_hired,
  results,
  testimonial_quote,
  testimonial_person_name,
  testimonial_person_title,
  banner_image,
  client_logo_url,
  created_at
) VALUES (
  gen_random_uuid(),
  'Customer support team for Care Hires',
  'Care Hires',
  'Care Workforce Management',
  ARRAY[
    'Customer Support Manager',
    'Customer Support Representative', 
    'Compliance Assistant',
    'Account Executive'
  ],
  ARRAY[
    'Processed 50,000+ care worker shifts monthly',
    'Achieved 100% compliance verification rate',
    'Reduced rota planning time by 75%',
    'Successfully managed 500+ agency relationships'
  ],
  'Our Sri Lankan team has been exceptional in managing complex healthcare staffing operations. Their meticulous attention to compliance checks and ability to efficiently handle rota management has been crucial to our service delivery.',
  'Ashley Haveloch-Jones',
  'COO at Care Hires',
  'https://cms.yourteaminasia.com/unlocking-global-potential-leveraging-sri-lankas-diverse-talent-pool-for-cost-effective-remote-work/hire-remote-workers-in-colombo-sri-lanka',
  'https://cms.yourteaminasia.com/carehires_logo/',
  now()
);