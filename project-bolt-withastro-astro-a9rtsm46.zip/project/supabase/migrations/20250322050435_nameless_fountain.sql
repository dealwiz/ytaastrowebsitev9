/*
  # Create Roles Table

  1. New Table
    - `roles`
      - `id` (text, primary key) - e.g., 'junior-accountant'
      - `title` (text) - e.g., 'Junior Accountant'
      - `category` (text) - e.g., 'finance-accounting'
      - `category_name` (text) - e.g., 'Finance & Accounting'
      - `category_description` (text)
      - `summary` (text)
      - `uk_salary_range` (text)
      - `lk_salary_range` (text)
      - `key_skills` (text[])
      - `responsibilities` (text[])
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  Notes:
    - Single table design for simplicity
    - Array types for skills and responsibilities
    - No RLS as specified
    - Automatic timestamps
*/

-- Create roles table
CREATE TABLE IF NOT EXISTS roles (
  id text PRIMARY KEY,
  title text NOT NULL,
  category text NOT NULL,
  category_name text NOT NULL,
  category_description text,
  summary text,
  uk_salary_range text,
  lk_salary_range text,
  key_skills text[] DEFAULT '{}',
  responsibilities text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create updated_at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger for updated_at
CREATE TRIGGER update_roles_updated_at
  BEFORE UPDATE ON roles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert existing data
INSERT INTO roles (
  id,
  title,
  category,
  category_name,
  category_description,
  summary,
  uk_salary_range,
  lk_salary_range,
  key_skills,
  responsibilities
) VALUES
-- Finance roles
(
  'junior-accountant',
  'Junior Accountant',
  'finance-accounting',
  'Finance & Accounting',
  'Financial professionals with expertise in UK accounting standards and practices',
  'Support accounting operations with basic financial tasks and learn UK accounting standards while working under senior supervision.',
  '£25,000 - £35,000',
  '£12,500 - £17,500',
  ARRAY['Basic Accounting', 'Financial Records', 'Data Entry', 'Excel', 'Attention to Detail', 'Accounting Software'],
  ARRAY['Assist with day-to-day accounting tasks', 'Process and record financial transactions', 'Help with month-end closing procedures', 'Support accounts payable and receivable', 'Maintain accurate financial records', 'Assist in preparing basic financial reports']
),
-- HR roles
(
  'hr-coordinator',
  'HR Coordinator',
  'hr',
  'Human Resources',
  'HR professionals experienced in UK employment practices and people management',
  'Support HR operations and employee lifecycle management while ensuring compliance with UK employment standards.',
  '£30,000 - £40,000',
  '£15,000 - £20,000',
  ARRAY['HR Administration', 'Employee Relations', 'HRIS Systems', 'UK Employment Law', 'Recruitment Support'],
  ARRAY['Manage employee records and documentation', 'Support recruitment and onboarding processes', 'Handle HR queries and requests', 'Assist with HR reporting and analytics', 'Coordinate employee benefits administration']
),
-- Virtual Assistant roles
(
  'executive-assistant',
  'Executive Assistant (EA)',
  'virtual-assistants',
  'Virtual Assistants',
  'Skilled virtual assistants providing comprehensive administrative and executive support',
  'Provide high-level administrative support to executives while managing schedules, communications, and projects efficiently.',
  '£35,000 - £50,000',
  '£17,500 - £25,000',
  ARRAY['Calendar Management', 'Email Management', 'Travel Arrangements', 'Document Preparation', 'Meeting Coordination', 'Project Support', 'Microsoft Office Suite'],
  ARRAY['Manage executive calendars and schedule meetings', 'Handle confidential communications and correspondence', 'Coordinate travel arrangements and prepare itineraries', 'Organize and maintain digital filing systems', 'Prepare reports, presentations, and documents', 'Support project management and follow-up tasks']
);