/*
  # Add Treat-it Medical Cannabis Clinic Case Study

  1. New Case Study
    - Title: Marketing team for Treat-it Medical Cannabis Clinic
    - Client: Treat-it Clinic
    - Industry: Medical Cannabis
    - Roles: Healthcare Marketing Manager, Medical Content Writer, Digital Marketing Specialist, Social Media Coordinator, Marketing Analytics Expert
    - Results: Increased patient inquiries by 300%, Achieved 65% reduction in patient acquisition cost, Maintained 100% marketing compliance, Expanded market reach across 5 new regions
    - Testimonial from Dr Mehran Afshar, Medical Director
*/

INSERT INTO case_studies (
  id,
  title,
  client_name,
  client_industry,
  roles_hired,
  results,
  testimonial_quote,
  testimonial_person_name,
  testimonial_person_title,
  banner_image,
  client_logo_url,
  client_description,
  created_at
) VALUES (
  gen_random_uuid(),
  'Marketing team for Treat-it Medical Cannabis Clinic',
  'Treat-it Clinic',
  'Medical Cannabis',
  ARRAY[
    'Healthcare Marketing Manager',
    'Medical Content Writer',
    'Digital Marketing Specialist',
    'Social Media Coordinator',
    'Marketing Analytics Expert'
  ],
  ARRAY[
    'Increased patient inquiries by 300%',
    'Achieved 65% reduction in patient acquisition cost',
    'Maintained 100% marketing compliance',
    'Expanded market reach across 5 new regions'
  ],
  'The team quickly mastered the complex regulatory landscape of medical cannabis marketing. They''ve launched highly effective, fully compliant campaigns that have transformed our patient outreach while maintaining strict adherence to advertising guidelines.',
  'Dr Mehran Afshar',
  'Medical Director at Treat-it Medical Cannabis Clinic',
  'https://cms.yourteaminasia.com/sri-lanka/',
  'https://cms.yourteaminasia.com/yta-client-treat-it-medical-cannabis-clinic-logo/',
  'Leading medical cannabis clinic providing consultations and prescriptions for patients across the UK, specializing in evidence-based cannabis treatments.',
  now()
);