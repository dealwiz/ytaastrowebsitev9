/*
  # Add GP Service Customer Support Team Case Study

  1. New Case Study
    - Title: Customer support team for The GP Service
    - Client: GP Service
    - Industry: Private Healthcare
    - Includes customer support and patient care roles
    - Contains testimonial from Medical Director
*/

INSERT INTO case_studies (
  id,
  title,
  client_name,
  client_industry,
  roles_hired,
  results,
  testimonial_quote,
  testimonial_person_name,
  testimonial_person_title,
  banner_image,
  client_logo_url,
  client_description,
  created_at
) VALUES (
  gen_random_uuid(),
  'Customer support team for The GP Service',
  'GP Service',
  'Private Healthcare',
  ARRAY[
    'Customer Support Team Lead',
    'Healthcare Support Specialist',
    'Patient Care Coordinator',
    'Technical Support Representative',
    'Quality Assurance Analyst'
  ],
  ARRAY[
    'Reduced response time from 30min to 2min',
    'Achieved 98% patient satisfaction rate',
    'Handled 10,000+ monthly patient inquiries',
    'Maintained 100% GDPR compliance'
  ],
  'YTA helped us establish an exceptional customer support team in Sri Lanka. Their dedication to patient care and technical knowledge has transformed our service delivery.',
  'Dr Shakil Alam',
  'Medical Director at The GP Service',
  'https://cms.yourteaminasia.com/sri-lanka/',
  'https://cms.yourteaminasia.com/gp-service/',
  'Digital healthcare provider offering online GP consultations, prescriptions, and healthcare services across the UK.',
  now()
);