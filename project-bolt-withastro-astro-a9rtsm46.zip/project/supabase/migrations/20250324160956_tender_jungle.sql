/*
  # Add IBC Healthcare Onboarding Team Case Study

  1. New Case Study
    - Title: Onboarding & Compliance team for IBC Healthcare
    - Client: IBC Healthcare
    - Industry: Specialist Care
    - Includes onboarding and compliance roles
    - Contains testimonial from Director People & Culture
*/

INSERT INTO case_studies (
  id,
  title,
  client_name,
  client_industry,
  roles_hired,
  results,
  testimonial_quote,
  testimonial_person_name,
  testimonial_person_title,
  banner_image,
  client_logo_url,
  client_description,
  created_at
) VALUES (
  gen_random_uuid(),
  'Onboarding & Compliance team for IBC Healthcare',
  'IBC Healthcare',
  'Specialist Care',
  ARRAY[
    'Onboarding Coordinator',
    'Compliance Specialist',
    'Training Administrator',
    'Document Control Officer'
  ],
  ARRAY[
    'Reduced onboarding time from 4 weeks to 1 week',
    'Achieved 100% CQC compliance documentation',
    'Automated 80% of onboarding processes',
    'Maintained training compliance rate of 99.8%'
  ],
  'YTA made it incredibly easy to recruit skilled HR professionals who quickly adapted to our processes and CQC requirements. Their team''s understanding of healthcare compliance has been invaluable in maintaining our high standards.',
  'Harika Thogarcheti',
  'Director People & Culture at IBC Healthcare',
  'https://cms.yourteaminasia.com/sri-lanka/',
  'https://cms.yourteaminasia.com/ibc-healthcare/',
  'Leading specialist care provider delivering high-quality care services across the UK, with a focus on complex care needs and specialist support.',
  now()
);