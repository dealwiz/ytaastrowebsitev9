/*
  # Create Case Studies Table

  1. New Table
    - `case_studies`
      - `id` (text, primary key)
      - `title` (text) - Title of the case study
      - `client_name` (text) - Name of the client
      - `client_industry` (text) - Industry sector
      - `roles_hired` (text[]) - Array of roles hired
      - `results` (text[]) - Array of key results/achievements
      - `testimonial_quote` (text) - Client testimonial
      - `testimonial_person_name` (text) - Name of person giving testimonial
      - `testimonial_person_title` (text) - Title of person giving testimonial
      - `banner_image` (text) - URL of banner image
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Notes
    - Array types for roles and results
    - Automatic timestamps
    - No RLS as specified
*/

-- Create case studies table
CREATE TABLE case_studies (
  id text PRIMARY KEY,
  title text NOT NULL,
  client_name text NOT NULL,
  client_industry text NOT NULL,
  roles_hired text[] DEFAULT '{}',
  results text[] DEFAULT '{}',
  testimonial_quote text NOT NULL,
  testimonial_person_name text NOT NULL,
  testimonial_person_title text NOT NULL,
  banner_image text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create trigger for updated_at
CREATE TRIGGER update_case_studies_updated_at
  BEFORE UPDATE ON case_studies
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Insert sample data
INSERT INTO case_studies (
  id,
  title,
  client_name,
  client_industry,
  roles_hired,
  results,
  testimonial_quote,
  testimonial_person_name,
  testimonial_person_title,
  banner_image
) VALUES (
  'care-hires-software-team',
  'Software development team for Care Hires',
  'Care Hires',
  'Care Workforce Management',
  ARRAY[
    'Angular Developer',
    'MongoDB Developer',
    'AWS DevOps Engineer',
    'QA Tester',
    'UI/UX Designer'
  ],
  ARRAY[
    'Successfully launched MVP within 4 months',
    'Secured Series A funding of £2.5M',
    'Achieved 99.9% platform uptime',
    'Reduced development costs by 60%'
  ],
  'Care Hires has had its software base in Sri Lanka from the beginning, and as we''ve grown, we''ve expanded beyond just development to include finance and customer support teams. The technical talent and dedication of our Sri Lankan team has been instrumental in our success.',
  'Ian Mattioli MBE',
  'Chairman at Care Hires',
  'https://cms.yourteaminasia.com/unlocking-global-potential-leveraging-sri-lankas-diverse-talent-pool-for-cost-effective-remote-work/hire-remote-workers-in-colombo-sri-lanka'
);