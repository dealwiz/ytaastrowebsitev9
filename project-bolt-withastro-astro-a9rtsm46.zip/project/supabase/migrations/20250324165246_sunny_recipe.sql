/*
  # Create inquiries table

  1. New Table
    - `inquiries`
      - `id` (uuid, primary key) - Unique identifier
      - `name` (text) - Applicant's name
      - `email` (text) - Work email
      - `telephone` (text) - Contact number
      - `requirements` (text) - Additional requirements
      - `role_url` (text) - URL of the page where form was submitted
      - `created_at` (timestamptz) - Submission timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  Notes:
    - Stores form submissions from Request Applicants forms
    - Includes URL tracking for role context
    - Automatic timestamps
*/

-- Create inquiries table
CREATE TABLE inquiries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  telephone text NOT NULL,
  requirements text,
  role_url text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create trigger for updated_at
CREATE TRIGGER update_inquiries_updated_at
  BEFORE UPDATE ON inquiries
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add comment
COMMENT ON TABLE inquiries IS 'Stores form submissions from Request Applicants forms across the site';