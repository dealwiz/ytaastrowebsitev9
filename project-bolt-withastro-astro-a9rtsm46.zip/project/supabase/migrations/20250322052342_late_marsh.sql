/*
  # Update IT Category Description

  1. Changes
    - Update category_description for all IT roles to match the new category name
    - Maintains consistency with the previously updated category_name

  Notes:
    - Updates category_description field
    - Affects all roles where category = 'it'
*/

UPDATE roles 
SET category_description = 'Technical professionals specializing in software development and IT operations'
WHERE category = 'it';