/*
  # Add Finance and Accounting Roles

  1. Changes
    - Add remaining finance and accounting roles to the roles table
    - Includes:
      - Finance Assistant
      - Management Accountant
      - Bookkeeping Assistant
      - Accounts Payable Assistant
      - Accounts Receivable Assistant
      - Finance Assistant
      - Management Accountant
      - Bookkeeping Assistant

  Notes:
    - Maintains consistent data structure
    - Preserves array format for skills and responsibilities
*/

INSERT INTO roles (
  id,
  title,
  category,
  category_name,
  category_description,
  summary,
  uk_salary_range,
  lk_salary_range,
  key_skills,
  responsibilities
) VALUES
(
  'finance-assistant',
  'Finance Assistant',
  'finance-accounting',
  'Finance & Accounting',
  'Financial professionals with expertise in UK accounting standards and practices',
  'Support day-to-day financial operations and assist with accounting tasks while ensuring accuracy and compliance with UK standards.',
  '£25,000 - £35,000',
  '£12,500 - £17,500',
  ARRAY['Bookkeeping', 'Data Entry', 'Financial Administration', 'Excel', 'Accounting Software'],
  ARRAY['Process financial transactions and reconciliations', 'Assist with accounts payable and receivable', 'Support month-end closing procedures', 'Maintain financial records and documentation', 'Help prepare basic financial reports', 'Handle general accounting queries']
),
(
  'management-accountant',
  'Management Accountant',
  'finance-accounting',
  'Finance & Accounting',
  'Financial professionals with expertise in UK accounting standards and practices',
  'Drive business performance through financial analysis and reporting while providing key insights for decision making.',
  '£45,000 - £60,000',
  '£22,500 - £30,000',
  ARRAY['Cost Accounting', 'Variance Analysis', 'Budgeting', 'Financial Modeling', 'Business Intelligence'],
  ARRAY['Prepare management accounts and KPI reports', 'Conduct financial analysis and forecasting', 'Support business decision-making with insights']
),
(
  'bookkeeping-assistant',
  'Bookkeeping Assistant',
  'finance-accounting',
  'Finance & Accounting',
  'Financial professionals with expertise in UK accounting standards and practices',
  'Support bookkeeping operations with accurate financial record keeping and reconciliation.',
  '£25,000 - £35,000',
  '£12,500 - £17,500',
  ARRAY['Bookkeeping', 'Bank Reconciliation', 'Financial Records', 'Sage/QuickBooks', 'Excel/Spreadsheets'],
  ARRAY['Maintain accurate financial records', 'Perform bank reconciliations', 'Process and record financial transactions', 'Assist with month-end closing procedures', 'Support preparation of financial reports']
),
(
  'accounts-payable-assistant',
  'Accounts Payable Assistant',
  'finance-accounting',
  'Finance & Accounting',
  'Financial professionals with expertise in UK accounting standards and practices',
  'Support accounts payable operations with accurate payment processing and vendor management.',
  '£25,000 - £35,000',
  '£12,500 - £17,500',
  ARRAY['AP/AR Management', 'Payment Processing', 'Vendor Management', 'Data Entry', 'Excel'],
  ARRAY['Process supplier invoices and payments', 'Maintain vendor records and documentation', 'Assist with payment reconciliations', 'Handle supplier queries and communications', 'Support month-end closing procedures']
),
(
  'accounts-receivable-assistant',
  'Accounts Receivable Assistant',
  'finance-accounting',
  'Finance & Accounting',
  'Financial professionals with expertise in UK accounting standards and practices',
  'Support accounts receivable operations with accurate invoice processing and customer account management.',
  '£25,000 - £35,000',
  '£12,500 - £17,500',
  ARRAY['AR Management', 'Invoice Processing', 'Credit Control', 'Collections', 'Customer Account Management'],
  ARRAY['Process customer invoices and payments', 'Maintain customer accounts and records', 'Perform payment reconciliations', 'Handle customer billing queries', 'Support credit control activities']
);