/*
  # Add GP Service Case Study

  1. New Data
    - Add a new case study record for The GP Service's software development team
    - Includes roles hired, results, and testimonial details
*/

INSERT INTO case_studies (
  id,
  title,
  client_name,
  client_industry,
  roles_hired,
  results,
  testimonial_quote,
  testimonial_person_name,
  testimonial_person_title,
  banner_image,
  client_logo_url,
  created_at
) VALUES (
  gen_random_uuid(),
  'Software development team for The GP Service',
  'GP Service',
  'Healthcare Technology',
  ARRAY[
    'Java Developer',
    'PostgreSQL Database Administrator',
    'Angular Frontend Developer',
    'IT Project Manager'
  ],
  ARRAY[
    'Reduced IT team costs by 50%',
    'Increased development velocity with shorter project timelines',
    'Improved code quality with fewer production issues',
    'Successfully documented existing system to manage technical debt'
  ],
  'YTA helped us build a high-performing software development team in Sri Lanka. The quality of Sri Lankan talent and their technical expertise has been exceptional.',
  'Suleman Sacranie',
  'CEO at The GP Service',
  'https://cms.yourteaminasia.com/unlocking-global-potential-leveraging-sri-lankas-diverse-talent-pool-for-cost-effective-remote-work/hire-remote-workers-in-colombo-sri-lanka',
  'https://cms.yourteaminasia.com/gp-service/',
  now()
);