/*
  # Create categories table and update roles schema

  1. New Tables
    - `categories`
      - `id` (text, primary key) - Unique identifier for the category
      - `name` (text) - Display name of the category
      - `description` (text) - Description of the category
      - `created_at` (timestamptz) - Creation timestamp
      - `updated_at` (timestamptz) - Last update timestamp

  2. Changes
    - Update roles table to reference categories table
    - Migrate existing category data
    - Add foreign key constraint

  3. Security
    - Enable RLS on categories table
    - Add policies for authenticated users
*/

-- Create categories table
CREATE TABLE categories (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create trigger for updated_at
CREATE TRIGGER update_categories_updated_at
  BEFORE UPDATE ON categories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Allow public read access to categories"
  ON categories
  FOR SELECT
  TO public
  USING (true);

-- Insert existing categories
INSERT INTO categories (id, name, description)
VALUES
  ('finance-accounting', 'Finance & Accounting', 'Financial professionals with expertise in UK accounting standards and practices'),
  ('software-it', 'Software & IT', 'Technical professionals specializing in software development and IT operations'),
  ('hr', 'Human Resources', 'HR professionals experienced in UK employment practices and people management'),
  ('virtual-assistants', 'Virtual Assistants', 'Skilled virtual assistants providing comprehensive administrative and executive support');

-- Update roles table
ALTER TABLE roles
  DROP COLUMN category_description,
  ADD CONSTRAINT fk_category
    FOREIGN KEY (category)
    REFERENCES categories(id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE;