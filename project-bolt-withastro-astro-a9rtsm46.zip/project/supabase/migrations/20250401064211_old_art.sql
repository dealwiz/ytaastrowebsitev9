/*
  # Add Marketing Category and Role

  1. Changes
    - Add marketing category if it doesn't exist
    - Add marketing assistant role for social care
    
  Notes:
    - Ensures category exists before adding role
    - Uses DO block for safe category creation
*/

-- First ensure the marketing category exists
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM categories WHERE id = 'marketing') THEN
    INSERT INTO categories (id, name, description)
    VALUES ('marketing', 'Marketing', 'Marketing professionals specializing in digital and traditional marketing strategies');
  END IF;
END $$;

-- Then add the marketing assistant role
INSERT INTO roles (
  id,
  title,
  category,
  summary,
  uk_salary_range,
  lk_salary_range,
  key_skills,
  responsibilities
) VALUES (
  'marketing-assistant-social-care',
  'Marketing Assistant - Social Care',
  'marketing',
  'Support marketing operations in social care settings with focus on resident communications, digital campaigns, and CQC-compliant content creation.',
  '£24,000 - £34,000',
  '£11,500 - £16,500',
  ARRAY[
    'Social Media Management',
    'Care Sector Marketing',
    'Content Creation',
    'CQC Compliance',
    'Digital Campaigns',
    'Email Marketing',
    'Analytics & Reporting'
  ],
  ARRAY[
    'Create and manage social media content for care services',
    'Develop CQC-compliant marketing materials',
    'Support resident and family communications',
    'Assist with digital marketing campaigns',
    'Track and report on marketing metrics',
    'Maintain website content and updates',
    'Coordinate resident testimonials and success stories'
  ]
);