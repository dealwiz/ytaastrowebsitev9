/*
  # Add IBC Healthcare Finance Team Case Study

  1. New Case Study
    - Title: Finance & Accounting team for IBC Healthcare
    - Client: IBC Healthcare
    - Industry: Specialist Care
    - Includes finance team roles and achievements
    - Contains testimonial from Head of Finance
*/

INSERT INTO case_studies (
  id,
  title,
  client_name,
  client_industry,
  roles_hired,
  results,
  testimonial_quote,
  testimonial_person_name,
  testimonial_person_title,
  banner_image,
  client_logo_url,
  client_description,
  created_at
) VALUES (
  gen_random_uuid(),
  'Finance & Accounting team for IBC Healthcare',
  'IBC Healthcare',
  'Specialist Care',
  ARRAY[
    'Finance Manager',
    'Payroll Processor',
    'AR/AP Assistant',
    'FP&A Analyst'
  ],
  ARRAY[
    'Successfully managed payroll for 1000+ healthcare staff',
    'Reduced month-end closing time by 60%',
    'Improved cash flow management by 45%',
    'Achieved 99.9% payroll accuracy rate'
  ],
  'YTA helped us extend our finance team with skilled professionals in Sri Lanka who seamlessly integrated with our operations. They''ve been crucial in managing our rapid growth.',
  'Rupa Dattani',
  'Head of Finance at IBC Healthcare',
  'https://cms.yourteaminasia.com/sri-lanka/',
  'https://cms.yourteaminasia.com/ibc-healthcare/',
  'Leading specialist care provider delivering high-quality care services across the UK, with a focus on complex care needs and specialist support.',
  now()
);