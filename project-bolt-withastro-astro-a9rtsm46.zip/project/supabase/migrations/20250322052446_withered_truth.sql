/*
  # Clean up category columns

  1. Changes
    - Remove redundant category_name column
    - Update category values to be more descriptive
    - Ensure category descriptions are properly mapped

  Notes:
    - Removes duplicate information
    - Makes the schema more maintainable
*/

-- First update categories to use more descriptive values
UPDATE roles 
SET category = 'software-it'
WHERE category = 'it';

-- Remove redundant category_name column
ALTER TABLE roles
DROP COLUMN category_name;