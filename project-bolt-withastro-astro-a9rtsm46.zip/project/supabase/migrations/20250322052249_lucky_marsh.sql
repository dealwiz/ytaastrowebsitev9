/*
  # Update IT Category Name

  1. Changes
    - Update category name from "Software Development" to "Software & IT" for all IT roles
    - Maintains data consistency across roles table

  Notes:
    - Updates both category_name field
    - Affects all roles where category = 'it'
*/

UPDATE roles 
SET category_name = 'Software & IT'
WHERE category = 'it';