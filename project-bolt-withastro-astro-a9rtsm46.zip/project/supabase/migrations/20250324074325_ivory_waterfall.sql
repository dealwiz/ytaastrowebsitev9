/*
  # Add client logo URL to case studies

  1. Changes
    - Add client_logo_url column to case_studies table
    - Update existing record with Care Hires logo
*/

-- Add the new column
ALTER TABLE case_studies 
ADD COLUMN client_logo_url text;

-- Update the Care Hires record with their logo
UPDATE case_studies 
SET client_logo_url = 'https://cms.yourteaminasia.com/carehires_logo/'
WHERE client_name = 'Care Hires';