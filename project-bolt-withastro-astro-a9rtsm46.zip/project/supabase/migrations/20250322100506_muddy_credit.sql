/*
  # Create Success Stories Table

  1. New Table
    - `success_stories`
      - `id` (text, primary key)
      - `role` (text)
      - `company` (text)
      - `department` (text)
      - `industry` (text)
      - `candidate_name` (text)
      - `location` (text)
      - `image_url` (text)
      - `testimonial` (text)
      - `impact` (text[])
      - `skills` (text[])
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  Notes:
    - Simple table structure without RLS
    - Includes automatic timestamps
*/

-- Create success stories table
CREATE TABLE success_stories (
  id text PRIMARY KEY,
  role text NOT NULL,
  company text NOT NULL,
  department text NOT NULL,
  industry text NOT NULL,
  candidate_name text NOT NULL,
  location text NOT NULL,
  image_url text NOT NULL,
  testimonial text NOT NULL,
  impact text[] DEFAULT '{}',
  skills text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create trigger for updated_at
CREATE TRIGGER update_success_stories_updated_at
  BEFORE UPDATE ON success_stories
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();