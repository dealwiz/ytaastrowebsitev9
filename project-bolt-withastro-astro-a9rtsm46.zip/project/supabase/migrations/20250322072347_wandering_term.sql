/*
  # Remove RLS and simplify schema

  1. Changes
    - Drop existing RLS policies
    - Disable RLS on all tables
    - Keep core table structure and relationships
*/

-- Disable RLS on categories table
ALTER TABLE categories DISABLE ROW LEVEL SECURITY;

-- Drop RLS policies
DROP POLICY IF EXISTS "Allow public read access to categories" ON categories;

-- Keep the foreign key relationship between roles and categories
ALTER TABLE roles
  DROP CONSTRAINT IF EXISTS fk_category,
  ADD CONSTRAINT fk_category
    FOREIGN KEY (category)
    REFERENCES categories(id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE;