/*
  # Add example success story

  1. Insert Data
    - Add one example success story to demonstrate the structure
*/

INSERT INTO success_stories (
  id,
  role,
  company,
  department,
  industry,
  candidate_name,
  location,
  image_url,
  testimonial,
  impact,
  skills
) VALUES
(
  'ishan-almeda',
  'Customer Support Manager',
  'Care Hires',
  'Customer Support',
  'Care Workforce Management',
  'Ishan Almeda',
  'Offshore (Sri Lanka → UK)',
  'https://cms.yourteaminasia.com/ishan-almeda-yta/',
  'Managing customer support for Care Hires has allowed me to make a real difference in healthcare staffing operations. YTA helped me find a role where I can lead a team that directly impacts healthcare delivery in the UK.',
  ARRAY[
    'Lead customer support strategy',
    'Implement support processes and standards',
    'Drive customer satisfaction improvements'
  ],
  ARRAY[
    'Customer Support',
    'Team Management',
    'Healthcare Operations'
  ]
);