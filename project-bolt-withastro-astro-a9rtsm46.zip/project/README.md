# Astro Business Website

A modern, high-performance business website built with Astro, React, and Tailwind CSS. This project demonstrates best practices for building fast, SEO-friendly business websites with modern web technologies.

## 🚀 Features

- **High Performance**: Built with Astro for optimal performance and minimal JavaScript
- **Modern Design**: Clean, professional UI with Tailwind CSS
- **Interactive Components**: React components for dynamic features
- **Responsive Layout**: Mobile-first design that works on all devices
- **SEO Optimized**: Built-in SEO best practices
- **Blog System**: Dynamic blog with categories and filtering
- **Contact Forms**: Interactive contact forms with validation
- **Industry Pages**: Detailed industry-specific content
- **Success Stories**: Customer testimonials and case studies
- **FAQ System**: Comprehensive FAQ section with search
- **Service Pages**: Detailed service offerings
- **Event Pages**: Event information and registration
- **Privacy Policy**: GDPR-compliant privacy policy

## 🛠️ Tech Stack

- [Astro](https://astro.build) - Static Site Generator
- [Supabase](https://supabase.com) - Database for roles and categories
- [WordPress](https://wordpress.org) - Headless CMS for blog content
- [React](https://reactjs.org) - UI Components
- [Tailwind CSS](https://tailwindcss.com) - Styling
- [Lucide Icons](https://lucide.dev) - Icons
- [date-fns](https://date-fns.org) - Date Formatting

## 📦 Project Structure

```
/
├── src/
│   ├── components/    # Reusable UI components
│   ├── layouts/       # Page layouts
│   ├── lib/          # Utility functions and API clients
│   │   └── supabase.ts  # Supabase client for roles data
│   ├── pages/        # Route pages
│   └── types/        # TypeScript type definitions
│       └── supabase.ts  # Supabase database types
├── supabase/
│   └── migrations/   # Database schema and seed data
└── public/          # Static assets
```
## 🗄️ Data Sources

- **Roles & Categories**: Stored in Supabase database
  - Job roles with detailed information
  - Role categories and descriptions
  - Managed through database migrations

- **Blog Content**: Pulled from WordPress CMS
  - Posts and categories via WP REST API
  - Media files and featured images
  - Content managed through WordPress admin
```

## 🚀 Getting Started

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm run dev
   ```
   The site will be available at `http://localhost:4321`

3. **Build for Production**
   ```bash
   npm run build
   ```

4. **Preview Production Build**
   ```bash
   npm run preview
   ```

5. **Connect to Supabase**
   - Click the "Connect to Supabase" button in the top right
   - This will set up the required environment variables

## 📄 Pages Overview

- **Home** (`/`): Landing page with key features and CTAs
- **About** (`/about`): Company information and team
- **Blog** (`/blog`): News and articles with category filtering
- **Contact** (`/contact`): Contact form and information
- **Design** (`/design`): Design system documentation
- **Event** (`/event`): Event information and registration
- **FAQ** (`/faq`): Searchable frequently asked questions
- **Industries** (`/industries`): Industry-specific solutions
- **Services** (`/services`): Service offerings and details
- **Success Stories** (`/success-stories`): Customer testimonials
- **Privacy** (`/privacy`): Privacy policy

## 🧩 Components

### Layout Components
- `Layout.astro`: Base layout with header and footer
- `Header.astro`: Navigation and branding
- `Footer.astro`: Site footer with links

### Feature Components
- `BlogCategories.astro`: Blog category filtering
- `Welcome.astro`: Homepage welcome section

## 🎨 Styling

The project uses Tailwind CSS for styling with a custom configuration:
- Custom color palette
- Responsive breakpoints
- Typography scale
- Custom components

## 🚀 Deployment

The site is deployed on Netlify with automatic deployments from the main branch.

## 📝 License

This project is MIT licensed.